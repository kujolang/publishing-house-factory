# Demo review

The five inspected source frames show the actual Factory Floor, article, first adaptation review, generated landing page and Kujo bumper. No scene labels or subtitles are added. The source text is deliberately held rather than animated line by line; narration carries the explanation. Long documents continue beyond their browser viewport, as they do in the app.

The weakest phone-size shots are the detailed article and JSON review. They establish the presence of actual evidence; viewers are not expected to read the full documents during the film. Full artifacts remain available in the repository and local viewer.

The narration and music are checked through duration, stream, loudness and decode measurements. Listening is not attested. Technical checks and visual frame inspection are not independent human creative approval.
