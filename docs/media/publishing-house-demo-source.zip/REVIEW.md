# Transition repair review

The user reported flashes and glitches between shots in the published second cut. Cut strips confirmed browser preroll leaking into product shots: the floor entered before its scroll position settled, and frames 1035–1066 showed a shrunken page on a gray background. Mid-scene screenshots alone had missed this defect.

The replacement captures begin with a screenshot of the loaded page after fonts and scroll position settle. Chrome screencast timestamps then preserve real interaction timing. Capture begins after setup, rather than estimating a trim from the recording's duration and a separate wall clock. Product footage stays at scale 1; the repeated 0.97-to-1 entrance zoom was removed. Existing focus/scroll preservation is used for station clicks. Final cut-strip inspection also caught the bumper’s initial empty white frames. Its entrance opacity delay was removed so the complete lockup appears on the first frame; the bumper was rerendered in HyperFrames and joined at frame 1426, preserving the existing audio stream.

Narration, music, scene lengths, actual evidence and Kujo bumper stay unchanged. No new voice generation was needed. Product shots remain real interactions with a completed campaign, not simulated agent execution.

Review must cover the first and last frames of every shot, all four cut strips and temporal outliers in the entire export. Automated absence of flash candidates alone is not creative approval. Audio is measured, not auditioned. The draft dialogs remain the densest shots, but are short supporting proof rather than required reading.

The editable project can be opened in the HyperFrames desktop app: https://hyperframes.studio/studio/download?src=cli.
