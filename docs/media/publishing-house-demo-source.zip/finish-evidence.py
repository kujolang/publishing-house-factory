from pathlib import Path
import subprocess,json,hashlib
w=Path('.runtime/demo-v3');movie=w/'output/draft.mp4'
subprocess.run(['python3',str(w/'check-frames.py'),str(movie),str(w/'review/after-scan.json')],check=True)
a=json.loads((w/'review/after-scan.json').read_text());assert not a['blankWhiteFrames'] and not a['blackFrames'] and not a['grayStartupFrames'] and not a['isolatedFlashCandidates']
for n,t in enumerate([11.6,21.68,34.48,47.52]):subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t-.15),'-i',str(movie),'-vf','scale=480:270,tile=4x3','-frames:v','1',str(w/f'review/after-cut-{n}.jpg')],check=True)
r={'sourceRun':'20261113-065550-16f495f8','durationSeconds':53.2,'frames':a['frames'],'before':{'sha256':json.loads((w/'review/before-scan.json').read_text())['sha256'],'grayStartupFrames':32,'affectedSeconds':[34.5,35.533]},'after':{'grayStartupFrames':0,'blackFrames':0,'blankWhiteFrames':0,'isolatedFlashCandidates':0},'cutTimesSeconds':[11.6,21.68,34.48,47.52],'repairs':['Capture starts only after page, fonts and scroll settle','Timestamped Chrome screencast replaces estimated preroll trimming','Product footage remains at scale 1 across cuts','Station selections preserve page position','Bumper logo and call to action visible on first frame'],'audio':'Existing narration and music reused; no new voice generation','limits':'Temporal scan is heuristic, supplemented by visual inspection of every cut; listening not attested.'}
(w/'review/transition-verification.json').write_text(json.dumps(r,indent=2)+'\n')

for name in ['narration.wav','music.wav']:
 assert (w/'assets'/name).read_bytes()==(Path('.runtime/demo-v2/assets')/name).read_bytes()
