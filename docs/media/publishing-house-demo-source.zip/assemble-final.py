from pathlib import Path
import subprocess
w=Path('.runtime/demo-v3/output');source=w/'draft-with-delayed-bumper.mp4'
if not source.exists():(w/'draft.mp4').rename(source)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(source),'-i',str(w/'bumper.mp4'),'-filter_complex','[0:v]trim=end_frame=1426,setpts=PTS-STARTPTS[a];[1:v]trim=end_frame=170,setpts=PTS-STARTPTS[b];[a][b]concat=n=2:v=1:a=0[v]','-map','[v]','-map','0:a','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-c:a','copy','-movflags','+faststart',str(w/'draft.mp4')],check=True)
subprocess.run(['ffmpeg','-v','error','-i',str(w/'draft.mp4'),'-f','null','-'],check=True)
