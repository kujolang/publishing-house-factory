from pathlib import Path
import subprocess,json,shutil
w=Path('.runtime/demo-v2'); assets=w/'assets'; scenes=[];start=0
for cue in ['intro','floor','review','outputs','bumper']:
 p=w/'audio/takes'/f'{cue}.mp3'; d=float(subprocess.check_output(['ffprobe','-v','quiet','-show_entries','format=duration','-of','csv=p=0',str(p)])); duration=round(d+.8,3)
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(p),'-af',f'adelay=200:all=1,apad,atrim=duration={duration}','-ar','48000','-ac','2',str(assets/f'{cue}.wav')],check=True)
 scenes.append(dict(id=cue,start=round(start,3),duration=duration,speechDuration=d,headline='',body='',assetId=None if cue=='bumper' else cue,theme='paper' if cue=='bumper' else 'ink'));start+=duration
(assets/'concat.txt').write_text(''.join(f"file '{s['id']}.wav'\n" for s in scenes))
subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(assets/'concat.txt'),'-af','loudnorm=I=-16:TP=-2:LRA=7','-ar','48000',str(assets/'narration.wav')],check=True)
for name in ['kujo-logo.svg','departure-mono.woff2','music.wav']:shutil.copy(Path('.runtime/demo/assets')/name,assets/name)
(w/'plan.json').write_text(json.dumps(dict(title='Publishing House Factory',width=1920,height=1080,fps=30,duration=round(start,3),cta='Build your next factory with Kujo.',scenes=scenes),indent=2))
print(start)
