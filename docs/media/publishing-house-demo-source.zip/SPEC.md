# Publishing House Factory demo

Selected story: follow one real campaign from the Factory Floor through article, independent review, output and Kujo bumper. Alternatives considered: an installation tutorial and a typography-led launch film. The requested match to the other factory demos favors the actual evidence walkthrough.

1920×1080, 30fps, 48.88 seconds. Ink background, actual browser captures, 3% camera push over the first 2.2 seconds of each shot. No added captions, top labels, bottom labels, invented metrics or first-person biography. The screenshots are held evidence, not a continuous live run. Browser text styling is enlarged for legibility without changing source contents.

ElevenLabs Siren, model eleven_v4, five newly generated cues. Scene windows follow each take's measured length plus 0.8 seconds. Original takes are retained. A quiet original Kujo synth bed sits beneath the narration. The official existing K SVG and Departure Mono close the film with “Build your next factory with Kujo” and kujolang.ai.

Source: run 20261113-065550-16f495f8. Review shot uses the actual first adaptation review, which requested corrections. Final output is a local candidate awaiting human review; no publication is implied.
