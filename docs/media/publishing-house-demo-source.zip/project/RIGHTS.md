# Media provenance

Kujo K SVG: reused from the existing Kujo factory video assets; brand mark for Kujo.
Departure Mono: font and license included in this project.
GSAP: bundled runtime from the existing pinned VideoOps video toolchain.
Narration: new ElevenLabs Siren (voice eXpIbVcVbLo8ZJQDlDnl), eleven_v4. Generation-time paid-tier receipts are retained with the local production source; no voice clone was created.
Music: original procedural Kujo synth bed, reused from the VideoOps demo; no external samples.
Screens: actual Publishing House Factory run 20261113-065550-16f495f8 and its preserved outputs, captured for this production. No third-party people or stock footage.
